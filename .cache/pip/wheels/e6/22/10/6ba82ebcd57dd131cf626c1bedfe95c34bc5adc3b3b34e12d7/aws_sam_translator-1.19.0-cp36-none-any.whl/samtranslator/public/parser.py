# flake8: noqa

from samtranslator.parser.parser import Parser
